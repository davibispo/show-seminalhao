@extends('layouts.base')

@section('content')

<div class="flex-center position-ref full-height">
    <div class="content">
        <div class="title m-b-md">
            Show do SEMINALHÃO
        </div>

        <div class="links">
            <a href="{{ route('site.index') }}">INICIAR</a>
        </div>
    </div>
</div>

@endsection