@extends('layouts.base')

@section('content')
    <div class="flex-center position-ref full-height">
        <div class="content">
            <div>
                <h1>Show do SEMINALHÃO</h1>
            </div>
            <div class="">
                <table class="table table-bordered">
                    <tr>
                        <td colspan="2">Qual é o ano de apresentação de Doutrina e Convênios e onde foi?</td>
                    </tr>
                    <tr>
                        <td style="width:10px"><h1>1</h1></td>
                        <td>Resposta</td>
                    </tr>
                    <tr>
                        <td><h1>2</h1></td>
                        <td>Resposta</td>
                    </tr>
                    <tr>
                        <td><h1>3</h1></td>
                        <td>Resposta</td>
                    </tr>
                    <tr>
                        <td><h1>4</h1></td>
                        <td>Resposta</td>
                    </tr>
                </table>
            </div>
    
            <div class="links">
                <a href="{{ route('site.index') }}">PULAR</a>
                <a href="{{ route('site.index') }}">AJUDA</a>
                <a href="{{ route('site.index') }}">PARAR</a>
            </div>
        </div>
    </div>
@endsection